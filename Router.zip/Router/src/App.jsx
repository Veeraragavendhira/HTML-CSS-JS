import { useDispatch, useSelector } from "react-redux";
import Counter from "./Counter";
import { increment, decrement } from "./CounterSlice";
function App() {
  return (
    <div>
      <Counter />
    </div>
  );
}

export default App;